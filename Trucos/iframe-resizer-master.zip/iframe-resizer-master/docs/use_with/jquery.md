## jQuery

This library also provides a simple jQuery interface

```js
$('iframe').iFrameResize([{ options }])
```
